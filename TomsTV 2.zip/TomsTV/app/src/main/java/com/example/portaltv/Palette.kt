package com.example.portaltv

import androidx.compose.ui.graphics.Color

/** Wählbare Schriftfarben. */
object Palette {
    val options: List<Pair<String, Color>> = listOf(
        "Weiß" to Color(0xFFFFFFFF),
        "Gelb" to Color(0xFFFFEB3B),
        "Hellblau" to Color(0xFF4FC3F7),
        "Grün" to Color(0xFF69F0AE),
        "Orange" to Color(0xFFFFA726),
        "Pink" to Color(0xFFFF80AB)
    )

    fun color(name: String): Color = options.firstOrNull { it.first == name }?.second ?: options[0].second
}

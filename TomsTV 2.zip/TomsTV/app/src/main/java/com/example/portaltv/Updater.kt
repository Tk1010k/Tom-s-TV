package com.example.portaltv

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/** Sucht neue Versionen in den GitHub-Releases und installiert sie. */
object Updater {
    data class Info(val tag: String, val number: Int, val url: String)

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun latest(): Info? {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isEmpty()) error("Diese App wurde nicht über GitHub gebaut, die Update-Adresse fehlt.")
        val req = Request.Builder()
            .url("https://api.github.com/repos/$repo/releases/latest")
            .header("Accept", "application/vnd.github+json")
            .header("User-Agent", "TomsTV")
            .build()
        return http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("GitHub antwortet mit Fehler ${r.code}")
            val o = JSONObject(r.body?.string().orEmpty())
            val tag = o.optString("tag_name")
            val number = tag.filter { it.isDigit() }.toIntOrNull() ?: 0
            val assets = o.optJSONArray("assets")
            var found: Info? = null
            if (assets != null) {
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (found == null && a.optString("name").endsWith(".apk")) {
                        found = Info(tag, number, a.getString("browser_download_url"))
                    }
                }
            }
            found
        }
    }

    fun download(ctx: Context, url: String, onProgress: (Int) -> Unit): File {
        val dir = File(ctx.cacheDir, "updates").apply { mkdirs() }
        val out = File(dir, "TomsTV.apk")
        val req = Request.Builder().url(url).header("User-Agent", "TomsTV").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Download fehlgeschlagen (${r.code})")
            val body = r.body ?: error("Leere Antwort beim Download")
            val total = body.contentLength()
            body.byteStream().use { input ->
                out.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024)
                    var read = 0L
                    var n: Int
                    while (input.read(buf).also { n = it } >= 0) {
                        o.write(buf, 0, n)
                        read += n
                        if (total > 0) onProgress((read * 100 / total).toInt())
                    }
                }
            }
        }
        return out
    }

    /** Gibt false zurück, wenn zuerst die Erlaubnis "Unbekannte Apps installieren" nötig ist. */
    fun install(ctx: Context, apk: File): Boolean {
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return false
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", apk)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return true
    }
}
